#pragma once

void initGrpcLog();
