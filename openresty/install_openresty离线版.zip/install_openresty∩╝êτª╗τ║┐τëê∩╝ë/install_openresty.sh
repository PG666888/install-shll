#!/usr/bin/env bash
set -e
set -o pipefail

# ============================
# 默认参数
# ============================
PREFIX="/usr/local/openresty"
ENABLE_OTEL=false
SKIP_CLEANUP=false

# ============================
# 参数解析
# ============================
while [[ $# -gt 0 ]]; do
    case $1 in
        --prefix=*)
            PREFIX="${1#*=}"
            ;;
        --with-otel)
            ENABLE_OTEL=true
            ;;
        --skip-cleanup)
            SKIP_CLEANUP=true
            ;;
        -h|--help)
            echo "Usage: $0 [--prefix=/path/to/install] [--with-otel] [--skip-cleanup]"
            exit 0
            ;;
        *)
            echo "Unknown option: $1"
            exit 1
            ;;
    esac
    shift
done

# ============================
# 检查 root 权限
# ============================
if [ "$EUID" -ne 0 ]; then
    echo "请使用 root 或 sudo 运行此脚本"
    exit 1
fi

# ============================
# 系统类型检测
# ============================
if [ -f /etc/lsb-release ] || [ -f /etc/debian_version ]; then
    OS="ubuntu"
elif [ -f /etc/centos-release ] || [ -f /etc/redhat-release ]; then
    OS="centos"
else
    echo "Unsupported OS"
    exit 1
fi
echo "Detected OS: $OS"

# ============================
# 安装依赖
# ============================
echo "Installing dependencies..."
if [ "$OS" == "ubuntu" ]; then
    apt update
    apt install -y build-essential libpcre3-dev zlib1g-dev libssl-dev \
        libgd-dev libgeoip-dev libmaxminddb-dev curl wget git cmake \
        autoconf automake libtool pkg-config linux-headers-generic
elif [ "$OS" == "centos" ]; then
    yum groupinstall -y "Development Tools"
    yum install -y pcre-devel zlib-devel openssl-devel gd-devel geoip-devel \
        libmaxminddb-devel curl wget git cmake autoconf automake libtool pkgconfig \
        kernel-headers
fi

# ============================
# 检测并安装 c-ares
# ============================
echo "Checking for c-ares..."
if [ "$OS" == "ubuntu" ]; then
    dpkg -s libc-ares-dev &>/dev/null || apt install -y libc-ares-dev
elif [ "$OS" == "centos" ]; then
    rpm -q c-ares-devel &>/dev/null || yum install -y c-ares-devel
fi

# ============================
# 下载 OpenResty
# ============================
echo "Downloading OpenResty..."
LATEST=$(curl -sSL https://openresty.org/en/download.html \
    | grep -oE 'openresty-[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+\.tar\.gz' \
    | sort -V | tail -n1)

if [ -z "$LATEST" ]; then
    echo "Failed to fetch latest version, using fallback version 1.23.4.5"
    LATEST="openresty-1.23.4.5.tar.gz"
fi

echo "OpenResty version: $LATEST"
curl -LO "https://openresty.org/download/$LATEST"

BUILD_DIR=$(mktemp -d)
tar -zxf "$LATEST" -C "$BUILD_DIR" --strip-components=1
rm -f "$LATEST"

# ============================
# 下载模块
# ============================
# echo "Downloading OpenResty..."

# # 固定版本
# LATEST="openresty-1.23.4.5.tar.gz"

# echo "OpenResty version: $LATEST"
# # 假设你本地已经下载好tar包，放在脚本当前目录下的 openresty 文件夹
# cp "./openresty/$LATEST" ./

# BUILD_DIR=$(mktemp -d)
# tar -zxf "$LATEST" -C "$BUILD_DIR" --strip-components=1
# rm -f "$LATEST"

# ============================
# 拷贝模块（当前脚本目录下的 modules 文件夹）
# ============================
echo "Copying local modules from ./modules..."

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)

cp -r "$SCRIPT_DIR/modules/ngx_brotli" "$BUILD_DIR/ngx_brotli"
#git -C "$BUILD_DIR/ngx_brotli" submodule update --init --recursive    要连github所以注释了
cp -r "$SCRIPT_DIR/modules/nginx-module-vts" "$BUILD_DIR/nginx-module-vts"
cp -r "$SCRIPT_DIR/modules/nginx-module-stream-sts" "$BUILD_DIR/nginx-module-stream-sts"
cp -r "$SCRIPT_DIR/modules/nginx-module-sts" "$BUILD_DIR/nginx-module-sts"
cp -r "$SCRIPT_DIR/modules/ngx_http_geoip2_module" "$BUILD_DIR/ngx_http_geoip2_module"

if $ENABLE_OTEL; then
    cp -r "$SCRIPT_DIR/modules/nginx-otel" "$BUILD_DIR/nginx-otel"
fi

cp "$SCRIPT_DIR/modules/Country.mmdb" "$BUILD_DIR/Country.mmdb"

# ============================
# 编译 OpenResty
# ============================
echo "Compiling OpenResty..."
cd "$BUILD_DIR"
CONFIG_ARGS="--prefix=$PREFIX \
    --with-http_dav_module \
    --with-http_addition_module \
    --with-http_realip_module \
    --with-http_sub_module \
    --with-http_flv_module \
    --with-http_mp4_module \
    --with-http_ssl_module \
    --with-http_v2_module \
    --with-http_gunzip_module \
    --with-http_stub_status_module \
    --with-http_gzip_static_module \
    --with-http_secure_link_module \
    --with-http_image_filter_module \
    --with-http_random_index_module \
    --with-http_auth_request_module \
    --with-stream \
    --with-stream_realip_module \
    --with-stream_ssl_module \
    --with-stream_ssl_preread_module \
    --with-stream_geoip_module=dynamic \
    --with-threads \
    --with-pcre \
    --with-pcre-jit \
    --with-compat \
    --add-module=$BUILD_DIR/ngx_brotli \
    --add-module=$BUILD_DIR/nginx-module-vts \
    --add-module=$BUILD_DIR/nginx-module-sts \
    --add-module=$BUILD_DIR/nginx-module-stream-sts \
    --add-module=$BUILD_DIR/ngx_http_geoip2_module"

if $ENABLE_OTEL; then
    CONFIG_ARGS="$CONFIG_ARGS --add-module=$BUILD_DIR/nginx-otel"
fi

./configure $CONFIG_ARGS
make -j$(nproc)
make install

# ============================
# 创建 openresty 用户和组
# ============================
if id "openresty" &>/dev/null; then
    echo "User 'openresty' already exists."
    if ! getent group openresty >/dev/null; then
        echo "Group 'openresty' missing, creating..."
        groupadd -r openresty
        usermod -g openresty openresty
    fi
else
    echo "Creating system user and group 'openresty'..."
    if [ "$OS" == "ubuntu" ]; then
        adduser --system --no-create-home --group --shell /usr/sbin/nologin openresty
    elif [ "$OS" == "centos" ]; then
        useradd -r -s /sbin/nologin -M -U openresty
    fi
fi

# ============================
# 配置文件和日志
# ============================
mkdir -p "$PREFIX/nginx/conf/conf.d"
cp "$BUILD_DIR/Country.mmdb" "$PREFIX/nginx/conf/Country.mmdb"

tee "$PREFIX/nginx/conf/nginx.conf" > /dev/null <<'EOF'
worker_processes auto;
user openresty;
pid /run/nginx.pid;

events {
    worker_connections 65535;
    use epoll;
    multi_accept on;
}



http {
    # 设置CDN服务器的IP地址范围
    set_real_ip_from 0.0.0.0/0;
    # 使用CDN传递的第一个IP作为真实IP
    real_ip_header   X-Forwarded-For;
    real_ip_recursive on;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;


    include   mime.types;
    log_format main '{ "@timestamp": "$time_iso8601", '
                                 '"remote_addr": "$remote_addr", '
                                 '"request_method": "$request_method", '
                                 '"uri": "$uri", '
                                 '"body_bytes_sent": $body_bytes_sent, '
                                 '"request_time": $request_time, '
                                 '"upstream_response_time": "$upstream_response_time", '
                                 '"status": "$status", '
                                 '"upstream_status": "$upstream_status", '
                                 '"request": "$request", '
                                 '"http_referrer": "$http_referer", '
                                 '"http_x_forwarded_for": "$http_x_forwarded_for", '
                                 '"http_user_agent": "$http_user_agent", '
                                '"host": "$host", '
                                '"server_port": "$server_port", '
                                '"upstream_addr": "$upstream_addr", '
                                '"scheme": "$scheme" }';


    sendfile            on;
    tcp_nopush          on;
    tcp_nodelay         on;
    keepalive_timeout   300;
    client_header_buffer_size 4k;
    open_file_cache max=102400 inactive=20s;
    open_file_cache_valid 30s;
    open_file_cache_min_uses 1;
    client_header_timeout 15;
    client_body_timeout 15;
    reset_timedout_connection on;
    send_timeout 150;
    server_tokens off;
    client_max_body_size 1024m;
    types_hash_max_size 4096;
    gzip on;
    gzip_vary  on;
    gzip_min_length  1k;
    gzip_buffers     16 16k;
    gzip_http_version 1.1;
    gzip_comp_level 3;
    gzip_types     text/plain application/javascript application/x-javascript text/javascript text/css application/xml;
    gzip_proxied   expired no-cache no-store private auth;
    gzip_disable   "MSIE [1-6]\.";
    fastcgi_connect_timeout     600;
    fastcgi_send_timeout 600;
    fastcgi_read_timeout 600;
    fastcgi_buffer_size 64k;
    fastcgi_buffers  4 64k;
    fastcgi_busy_buffers_size 128k;
    fastcgi_temp_file_write_size 128k;
    fastcgi_temp_path nginx_tmp;
    fastcgi_intercept_errors on;
    fastcgi_cache_path fastcgi_cache levels=1:2 keys_zone=cache_fastcgi:128m inactive=1d max_size=10g;

    proxy_buffering on;
    proxy_buffers 16 32k;
    proxy_buffer_size 32k; 

    variables_hash_max_size 2048;
    variables_hash_bucket_size 128;

    #静态文件让缓存久一点
    proxy_cache_path cache levels=1:2 keys_zone=cache:100m max_size=300g inactive=8064d use_temp_path=off;

    # 定义全局请求限制区域
    # $binary_remote_addr: 客户端 IP 地址（用二进制表示）
    # zone=one:10m: 使用一个名为 one 的 zone，大小为 10MB
    # rate=1r/s: 每秒钟只允许 1 个请求
    limit_req_zone $binary_remote_addr zone=one:100m rate=20r/s;
    limit_req_zone $binary_remote_addr zone=req_api_zone:100m rate=20r/s;
    limit_req_zone $binary_remote_addr zone=req_ws_zone:100m rate=10r/s;


    brotli on;
    brotli_comp_level 6;
    brotli_static on;
    brotli_types application/atom+xml application/javascript application/json application/rss+xml
             application/vnd.ms-fontobject application/x-font-opentype application/x-font-truetype
             application/x-font-ttf application/x-javascript application/xhtml+xml application/xml
             font/eot font/opentype font/otf font/truetype image/svg+xml image/vnd.microsoft.icon
             image/x-icon image/x-win-bitmap text/css text/javascript text/plain text/xml;

    include /usr/local/openresty/nginx/conf/conf.d/*.conf;
   }
EOF

tee "$PREFIX/nginx/conf/conf.d/ssl-verify.conf" > /dev/null <<EOF
server {
    listen 80;

    location ^~ /.well-known/pki-validation/ {
        alias $PREFIX/nginx/conf/ssl-verify/;
        try_files \$uri =404;  # 确保文件存在否则返回404
        access_log off;
    }
}
EOF

tee "$PREFIX/nginx/conf/conf.d/stub_status.conf" > /dev/null <<EOF
server {
        listen 8088;
        listen [::]:8088;
        server_name localhost;
        location = /stub_status {
            stub_status;
            access_log off; #监控接口没必要写日志
            allow 127.0.0.1;       # 仅允许本机访问
            allow ::1;             # 允许 IPv6 本地
            # allow 192.168.1.0/24; # 可以加内网段
            deny all;              # 拒绝其他访问
            default_type text/plain;
        }
	    # 健康检查接口, 使用精确匹配, 稍微提高响应的效率
        location = /health {
            add_header Content-Type application/json;
            add_header access-control-allow-credentials true;
            add_header Access-Control-Allow-Origin "*" always;
            add_header Access-Control-Allow-Methods "PUT, GET, POST, DELETE, HEAD, OPTIONS, PATCH" always;
            add_header Access-Control-Allow-Headers "Authorization, Content-Type, X-Requested-With, X-CSRF-Token, Accept, Origin, DNT, User-Agent, Keep-Alive, X-Mx-ReqToken, If-Modified-Since, Cache-Control" always;
            return 200 '{"code": 200, "msg": "ok", "version": "2.0"}';
        }
}
EOF


tee "$PREFIX/nginx/conf/conf.d/video.conf" > /dev/null <<EOF
map \$request_uri \$ts_cache_key {
    # 只取问号前的路径部分，例如：
    # /satty/movie/.../part-1.ts?token=xxx  -> /satty/movie/.../part-1.ts
    ~^(?<base>[^?]+)\\?.*\$ \$base;
    default \$request_uri;
}
server {
    listen 31552 ssl;

    access_log /var/log/nginx/proxy_static_proxy.log main;
    error_log /var/log/nginx/proxy_static_proxy.error.log;

    # SSL 证书
     #cat example.crt ca.crt > fullchain.pem  通过这个获得pem
    ssl_certificate $PREFIX/nginx/conf/ssl/ip.pem;
    ssl_certificate_key $PREFIX/nginx/conf/ssl/ip.key;

    ssl_session_timeout 5m;
    ssl_protocols TLSv1 TLSv1.1 TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers on;
    ssl_ciphers "TLS13-AES-256-GCM-SHA384:TLS13-CHACHA20-POLY1305-SHA256:TLS13-AES-128-GCM-SHA256:TLS13-AES-128-CCM-8-SHA256:TLS13-AES-128-CCM-SHA256:EECDH+CHACHA20:EECDH+CHACHA20-draft:EECDH+AES128:RSA+AES128:EECDH+AES256:RSA+AES256:EECDH+3DES:RSA+3DES:!MD5";
    ssl_session_cache builtin:1000 shared:SSL:10m;

    # -------------------------
    # S3 视频代理
    # -------------------------
    location / {
        add_header Access-Control-Allow-Origin * always;
        add_header Access-Control-Allow-Methods 'GET, OPTIONS' always;
        add_header Access-Control-Allow-Headers 'DNT, X-Mx-ReqToken, Keep-Alive, User-Agent, X-Requested-With, If-Modified-Since, Cache-Control, Content-Type, Authorization' always;
        proxy_ssl_server_name on;
        proxy_ssl_name kj-video-img-pro.s3-accelerate.amazonaws.com;
        proxy_pass https://kj-video-img-pro.s3-accelerate.amazonaws.com;
        proxy_set_header Referer https://kj-video-img-pro.s3-accelerate.amazonaws.com;
        proxy_set_header Host kj-video-img-pro.s3-accelerate.amazonaws.com;

        # 缓存 90 天
        proxy_cache cache;
        proxy_cache_key "\$scheme\$proxy_host\$request_uri";
        proxy_cache_valid 200 301 302 90d;
        proxy_cache_use_stale error timeout updating;
        add_header X-Cache-Status \$upstream_cache_status always;
    }

    # -------------------------
    # /satty/ 视频/流接口
    # -------------------------
    location /satty/ {
        #limit_req zone=req_api_zone burst=10 delay=10;
        #limit_req_status 429;
    # 隐藏上游返回的 CORS 响应头
    proxy_hide_header Access-Control-Allow-Origin;
    proxy_hide_header Access-Control-Allow-Methods;
    proxy_hide_header Access-Control-Allow-Headers;

    # 在 Nginx 层统一添加你自己的跨域头
    add_header Access-Control-Allow-Origin * always;
    add_header Access-Control-Allow-Methods 'GET, OPTIONS' always;
    add_header Access-Control-Allow-Headers 'DNT, X-Mx-ReqToken, Keep-Alive, User-Agent, X-Requested-With, If-Modified-Since, Cache-Control, Content-Type, Authorization' always;

    # 处理 OPTIONS 预检请求
    if (\$request_method = OPTIONS) {
        add_header Access-Control-Max-Age 1728000;
        add_header Content-Type 'text/plain charset=UTF-8';
        add_header Content-Length 0;
        return 204;
    }
        set \$client_ip \$remote_addr;

        proxy_ssl_server_name on;
        proxy_ssl_name auth.mfaanqaa.com;
        proxy_pass https://auth.mfaanqaa.com/;
        proxy_set_header Referer https://auth.mfaanqaa.com;
        proxy_set_header Host auth.mfaanqaa.com;

        proxy_buffering off;    # 流式传输
        proxy_cache off;        # 视频一般不缓存
        proxy_set_header X-Ngnix-Proxy true;

        proxy_read_timeout 86400s;
        proxy_send_timeout 86400s;
        proxy_connect_timeout 86400s;
        send_timeout 3600s;
        proxy_intercept_errors off;

        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    location ~* ^/satty/(.+\\.ts)\$ {
        set \$client_ip \$remote_addr;
        # -------------------------
        # 上游代理配置
        # -------------------------
        rewrite ^/satty/(.+)\$ /\$1 break;
        proxy_ssl_server_name on;
        proxy_ssl_name auth.mfaanqaa.com;
        proxy_pass https://auth.mfaanqaa.com;
        proxy_set_header Referer https://auth.mfaanqaa.com;
        proxy_set_header Host auth.mfaanqaa.com;
    
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    
        # -------------------------
        # CORS 处理
        # -------------------------
        # 先隐藏上游的 CORS 头，避免冲突
        proxy_hide_header Access-Control-Allow-Origin;
        proxy_hide_header Access-Control-Allow-Methods;
        proxy_hide_header Access-Control-Allow-Headers;
    
        # 再由 Nginx 自己统一添加
        add_header Access-Control-Allow-Origin * always;
        add_header Access-Control-Allow-Methods 'GET, OPTIONS' always;
        add_header Access-Control-Allow-Headers 'DNT, X-Mx-ReqToken, Keep-Alive, User-Agent, X-Requested-With, If-Modified-Since, Cache-Control, Content-Type, Authorization' always;
    
        # 处理预检请求
        if (\$request_method = OPTIONS) {
        add_header Access-Control-Max-Age 1728000;
        add_header Content-Type 'text/plain charset=UTF-8';
        add_header Content-Length 0;
        return 204;
        }
    
        # -------------------------
        # 缓存配置
        # -------------------------
        proxy_cache cache;
    
        # 缓存键仅使用 URL 主体（忽略 token 参数）
        proxy_cache_key "\$scheme\$proxy_host\$ts_cache_key";
    
        # 缓存有效期与失效策略
        proxy_cache_valid 200 206 90d;
        proxy_cache_use_stale error timeout updating http_500 http_502 http_503 http_504;
    
        # 支持断点续传
        proxy_force_ranges on;
    
        # 添加缓存状态调试头
        add_header X-Cache-Status \$upstream_cache_status always;
    
        # -------------------------
        # 超时配置
        # -------------------------
        proxy_read_timeout 86400s;
        proxy_send_timeout 86400s;
        proxy_connect_timeout 86400s;
        send_timeout 3600s;
        proxy_intercept_errors off;
    }
    # 缓存 m3u8 文件（播放索引）
    location ~* ^/satty/(.+\\.m3u8)\$ {
        set \$client_ip \$remote_addr;
        rewrite ^/satty/(.+)\$ /\$1 break;
        proxy_ssl_server_name on;
        proxy_ssl_name auth.mfaanqaa.com;
        proxy_pass https://auth.mfaanqaa.com;
        proxy_set_header Referer https://auth.mfaanqaa.com;
        proxy_set_header Host auth.mfaanqaa.com;
    
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    
        # -------------------------
        # CORS
        # -------------------------
        proxy_hide_header Access-Control-Allow-Origin;
        proxy_hide_header Access-Control-Allow-Methods;
        proxy_hide_header Access-Control-Allow-Headers;
    
        add_header Access-Control-Allow-Origin * always;
        add_header Access-Control-Allow-Methods 'GET, OPTIONS' always;
        add_header Access-Control-Allow-Headers 'DNT, X-Mx-ReqToken, Keep-Alive, User-Agent, X-Requested-With, If-Modified-Since, Cache-Control, Content-Type, Authorization' always;
    
        if (\$request_method = OPTIONS) {
            add_header Access-Control-Max-Age 1728000;
            add_header Content-Type 'text/plain charset=UTF-8';
            add_header Content-Length 0;
            return 204;
        }
    
        # -------------------------
        # 缓存配置
        # -------------------------
        proxy_cache cache;
        proxy_cache_key "\$scheme\$proxy_host\$ts_cache_key";
        proxy_cache_valid 200 302 7d;
        proxy_cache_use_stale error timeout updating http_500 http_502 http_503 http_504;
    
        add_header X-Cache-Status \$upstream_cache_status always;
    
            # -------------------------
            # 超时配置
            # -------------------------
        proxy_read_timeout 86400s;
        proxy_send_timeout 86400s;
        proxy_connect_timeout 86400s;
        send_timeout 3600s;
        proxy_intercept_errors off;
    }
    # -------------------------
    # /sattys1/ 图片桶
    # -------------------------
    location /sattys1/ {
        add_header Access-Control-Allow-Origin * always;
        add_header Access-Control-Allow-Methods 'GET, OPTIONS' always;
        add_header Access-Control-Allow-Headers 'DNT, X-Mx-ReqToken, Keep-Alive, User-Agent, X-Requested-With, If-Modified-Since, Cache-Control, Content-Type, Authorization' always;
 
        proxy_ssl_server_name on;
        proxy_ssl_name video-saas-pic-pro.s3.ap-northeast-1.amazonaws.com;
        proxy_pass https://video-saas-pic-pro.s3.ap-northeast-1.amazonaws.com/;
        proxy_set_header Referer https://video-saas-pic-pro.s3.ap-northeast-1.amazonaws.com;
        proxy_set_header Host video-saas-pic-pro.s3.ap-northeast-1.amazonaws.com;

        # 缓存 90 天
        proxy_cache cache;
        proxy_cache_key "\$scheme\$proxy_host\$request_uri";
        proxy_cache_valid 200 301 302 90d;
        proxy_cache_use_stale error timeout updating;
        add_header X-Cache-Status \$upstream_cache_status always;
    }
}
EOF


mkdir -p /var/log/nginx /var/log/openresty $PREFIX/nginx/conf/ssl $PREFIX/nginx/conf/ssl-verify
touch /var/log/nginx/access.log /var/log/nginx/error.log
chown -R openresty:openresty "$PREFIX" /var/log/nginx /var/log/openresty 
ln -s $PREFIX/nginx/sbin/nginx /usr/bin
ln -s $PREFIX/bin/openresty /usr/bin


# ============================
# systemd 服务
# ============================
tee /etc/systemd/system/openresty.service > /dev/null <<EOF
[Unit]
Description=OpenResty (Nginx) Service
After=network.target

[Service]
Type=forking
User=root
Group=root
PIDFile=/var/run/nginx.pid
ExecStart=$PREFIX/bin/openresty
ExecReload=$PREFIX/bin/openresty -s reload
ExecStop=$PREFIX/bin/openresty -s quit
PrivateTmp=true
NoNewPrivileges=true
LimitNOFILE=65535
Restart=on-failure
RestartSec=5s

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable openresty
#systemctl restart openresty

# ============================
# 清理临时文件
# ============================
if ! $SKIP_CLEANUP; then
    rm -rf "$BUILD_DIR"
fi

echo "✅ OpenResty 安装完成"
echo "请启动后查看状态: systemctl status openresty"
echo "请去https://zerossl.com申请ip证书合并后放到$PREFIX/nginx/conf/ssl 名称为ip.pem ip.key"




